package com.photoapp.api.users;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotAppApiUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
